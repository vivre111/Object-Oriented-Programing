#include "BookVisitor.h"

BookVisitor::~BookVisitor() {}
