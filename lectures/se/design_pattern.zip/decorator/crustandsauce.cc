#include <string>
#include "crustandsauce.h"
using namespace std;

float CrustAndSauce::price() { return 5.99; }

string CrustAndSauce::description() { return "Pizza"; }
