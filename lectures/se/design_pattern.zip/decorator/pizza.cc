#include "pizza.h"

Pizza::~Pizza() {}
