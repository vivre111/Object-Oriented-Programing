#include "absOperation.h"



AbsOperation::~AbsOperation(){}
