#ifndef _ERROR__H_
#define _ERROR__H_

class DirectionNF{};


#endif
