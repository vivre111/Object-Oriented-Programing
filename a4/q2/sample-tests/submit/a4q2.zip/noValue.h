#ifndef _NOVALUE__H_
#define _NOVALUE__H_
#include <string>
class NoValue{
	public:
		std::string s;
		NoValue(std::string s);
	};

#endif
