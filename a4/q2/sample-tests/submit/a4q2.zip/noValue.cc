#include "noValue.h"
using namespace std;	
NoValue::NoValue(string s):s{s}{}
	
